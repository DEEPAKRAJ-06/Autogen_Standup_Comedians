
import json
import sys
import os
import google.generativeai as genai
from typing import Dict, List, Any

# Set up Gemini API
GOOGLE_API_KEY = os.environ.get("GOOGLE_API_KEY")
if not GOOGLE_API_KEY:
    raise ValueError("GOOGLE_API_KEY environment variable is not set")
    
genai.configure(api_key=GOOGLE_API_KEY)

# Initialize the model
model = genai.GenerativeModel(model_name="gemini-1.5-flash")

# Define the comedians and their personalities
comedians = {
    "cathy": {
        "name": "Cathy",
        "personality": "Indian stand-up comedian who keeps jokes like a natural conversation rather than cringy jokes. Uses observational comedy style."
    },
    "joe": {
        "name": "Joe",
        "personality": "Indian stand-up comedian who builds on the punchlines of previous jokes. Uses observational comedy style."
    }
}

# Start the conversation
conversation = [
    {
        "speaker": "joe",
        "message": f"Hey Cathy, let's start our comedy routine about Comedy. I'll kick things off!"
    }
]

# Function to generate the next response in the conversation
def generate_comedy_response(current_speaker, other_speaker, conversation_history, topic):
    # Context for the AI
    prompt = f"""
You are {comedians[current_speaker]['name']}, {comedians[current_speaker]['personality']}
You're performing a stand-up comedy routine with {comedians[other_speaker]['name']} about {topic}.
The conversation so far:

"""
    # Add conversation history to the prompt
    for msg in conversation_history:
        prompt += f"{comedians[msg['speaker']]['name']}: {msg['message']}\n"
    
    prompt += f"\nNow continue as {comedians[current_speaker]['name']}. Keep your response concise (under 100 words) and funny. Don't explain the joke."
    
    # Generate response from Gemini
    try:
        response = model.generate_content(prompt)
        
        # Clean up the response to remove the name prefix if it exists
        message = response.text.strip()
        name_prefix = f"{comedians[current_speaker]['name']}: "
        if message.startswith(name_prefix):
            message = message[len(name_prefix):].strip()
            
        return message
    except Exception as e:
        print(f"Error generating response: {str(e)}")
        return f"Sorry, I'm having a creative block about {topic}..."

# Generate the conversation
current_turn = 0
max_turns = 5

try:
    # Alternate between comedians
    while current_turn < max_turns:
        # Cathy's turn
        cathy_response = generate_comedy_response(
            current_speaker="cathy", 
            other_speaker="joe", 
            conversation_history=conversation,
            topic="Comedy"
        )
        conversation.append({"speaker": "cathy", "message": cathy_response})
        
        if current_turn < max_turns - 1:  # Check if Joe should respond
            # Joe's turn
            joe_response = generate_comedy_response(
                current_speaker="joe", 
                other_speaker="cathy", 
                conversation_history=conversation,
                topic="Comedy"
            )
            conversation.append({"speaker": "joe", "message": joe_response})
        
        current_turn += 1
    
    # Output the results
    result = {"messages": conversation}
    print(json.dumps(result))
except Exception as e:
    print(json.dumps({"error": str(e)}), file=sys.stderr)
    sys.exit(1)

# Output already handled when conversation is complete
# No additional processing needed
print(json.dumps(result))
