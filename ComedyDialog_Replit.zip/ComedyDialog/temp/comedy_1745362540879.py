
import json
import sys
import os
import autogen

# Load the configuration list
config_list_gemini = autogen.config_list_from_json("./temp/OAI_CONFIG_LIST")

# Define the comedians
cathy = autogen.ConversableAgent(
    name="cathy",
    system_message=
    "Your name is Cathy and you are an Indian stand-up comedian. Keep the jokes like a natural conversation rather than cringy jokes. The standup comedy show should be on the topic of Arranged Marriages. Use observational comedy style.",
    llm_config={"config_list": config_list_gemini},
    human_input_mode="NEVER",
)

joe = autogen.ConversableAgent(
    name="joe",
    system_message=
    "Your name is Joe and you are an Indian stand-up comedian. The comedy show is about Arranged Marriages. Use observational comedy style. Start the next joke from the punchline of the previous joke.",
    llm_config={"config_list": config_list_gemini},
    human_input_mode="NEVER",
)

# Start the conversation
chat_result = joe.initiate_chat(
    recipient=cathy, 
    message=f"Hey Cathy, let's start our comedy routine about Arranged Marriages. I'll kick things off!",
    max_turns=5,
)

# Extract messages from the conversation
messages = []
for msg in cathy.chat_messages[joe]:
    if msg["role"] == "user":
        messages.append({"speaker": "joe", "message": msg["content"]})
for msg in joe.chat_messages[cathy]:
    if msg["role"] == "user":
        messages.append({"speaker": "cathy", "message": msg["content"]})

# Sort messages by their index in the conversation
sorted_messages = []
msg_index = 0
total_msgs = len(messages)
while msg_index < total_msgs:
    if msg_index < len(joe.chat_messages[cathy]):
        joe_msg = joe.chat_messages[cathy][msg_index]
        if joe_msg["role"] == "user":
            sorted_messages.append({"speaker": "joe", "message": joe_msg["content"]})
    
    if msg_index < len(cathy.chat_messages[joe]):
        cathy_msg = cathy.chat_messages[joe][msg_index]
        if cathy_msg["role"] == "user":
            sorted_messages.append({"speaker": "cathy", "message": cathy_msg["content"]})
    
    msg_index += 1

# Output the results
result = {"messages": sorted_messages}
print(json.dumps(result))
