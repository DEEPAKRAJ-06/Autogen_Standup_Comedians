// DOM Elements
const conversationContainer = document.getElementById('conversation');
const loadingOverlay = document.getElementById('loading-overlay');
const currentTopicBadge = document.getElementById('current-topic');
const audienceCountElement = document.getElementById('audience-count');
const topicSelect = document.getElementById('topic-select');
const customTopicInput = document.getElementById('custom-topic');
const startButton = document.getElementById('start-btn');
const resetButton = document.getElementById('reset-btn');
const decreaseTurnsButton = document.getElementById('decrease-turns');
const increaseTurnsButton = document.getElementById('increase-turns');
const turnsDisplay = document.getElementById('turns-display');
const styleSelect = document.getElementById('style-select');

// State variables
let turns = 5;
let socket;
let isConnected = false;
let reconnectAttempts = 0;
const maxReconnectAttempts = 5;
let reconnectInterval;
let reconnectDelay = 1500; // Initial delay in ms

// Utility functions
function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function updateAudienceCount() {
  const randomAudience = getRandomInt(30, 120);
  audienceCountElement.textContent = randomAudience;
}

function showLoading() {
  loadingOverlay.classList.add('active');
  startButton.disabled = true;
}

function hideLoading() {
  loadingOverlay.classList.remove('active');
  startButton.disabled = false;
}

function formatTimestamp(date) {
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function createMessageElement(comedian, content, timestamp) {
  const messageDiv = document.createElement('div');
  messageDiv.className = `message ${comedian}`;
  
  // Skip comedian header for system messages
  if (comedian === 'system') {
    messageDiv.innerHTML = `
      <div class="message-bubble">
        ${content}
      </div>
    `;
  } else {
    messageDiv.innerHTML = `
      <div class="message-header">
        <span class="comedian-name">${comedian === 'joe' ? 'Joe' : 'Cathy'}</span>
        <span class="timestamp">${formatTimestamp(timestamp)}</span>
      </div>
      <div class="message-bubble">
        ${content}
      </div>
    `;
  }
  
  return messageDiv;
}

function addMessageToConversation(comedian, content, timestamp) {
  const message = createMessageElement(comedian, content, timestamp);
  conversationContainer.appendChild(message);
  conversationContainer.scrollTop = conversationContainer.scrollHeight;
}

function clearConversation() {
  while (conversationContainer.firstChild) {
    conversationContainer.removeChild(conversationContainer.firstChild);
  }
}

function displayWelcomeMessage() {
  const welcomeDiv = document.createElement('div');
  welcomeDiv.className = 'welcome-message';
  welcomeDiv.innerHTML = '<p>Select a topic to start the comedy conversation!</p>';
  conversationContainer.appendChild(welcomeDiv);
}

function displayErrorMessage(message) {
  const errorDiv = document.createElement('div');
  errorDiv.className = 'message system error';
  errorDiv.innerHTML = `
    <div class="message-bubble" style="background-color: #ef4444;">
      Error: ${message}
    </div>
  `;
  conversationContainer.appendChild(errorDiv);
  conversationContainer.scrollTop = conversationContainer.scrollHeight;
}

// WebSocket functions
function connectWebSocket() {
  // Get the base URL based on window location
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const host = window.location.hostname;
  const port = window.location.port;
  const wsUrl = `${protocol}//${host}${port ? ':' + port : ''}/ws/comedy`;
  
  console.log(`Connecting to WebSocket at: ${wsUrl}`);
  
  socket = new WebSocket(wsUrl);
  
  socket.onopen = () => {
    console.log('WebSocket connection established');
    isConnected = true;
    reconnectAttempts = 0;
    
    // Clear any pending reconnect attempts
    if (reconnectInterval) {
      clearTimeout(reconnectInterval);
      reconnectInterval = null;
    }
  };
  
  socket.onmessage = (event) => {
    try {
      const message = JSON.parse(event.data);
      handleWebSocketMessage(message);
    } catch (error) {
      console.error('Error parsing WebSocket message:', error);
    }
  };
  
  socket.onclose = (event) => {
    console.log('WebSocket connection closed:', event.code, event.reason);
    isConnected = false;
    
    if (reconnectAttempts < maxReconnectAttempts) {
      reconnectAttempts++;
      console.log(`Attempting to reconnect in ${reconnectDelay / 1000}s (attempt ${reconnectAttempts})`);
      
      reconnectInterval = setTimeout(() => {
        connectWebSocket();
      }, reconnectDelay);
      
      // Increase delay for next attempt (exponential backoff)
      reconnectDelay = Math.min(reconnectDelay * 1.5, 10000);
    } else {
      console.log('Maximum reconnection attempts reached');
      displayErrorMessage('Connection lost. Please refresh the page to reconnect.');
    }
  };
  
  socket.onerror = (error) => {
    console.error('WebSocket error:', error);
  };
}

function handleWebSocketMessage(message) {
  const messageType = message.type;
  const payload = message.payload;
  
  console.log('Received message type:', messageType);
  
  switch (messageType) {
    case 'message':
      const comedian = payload.comedian;
      const content = payload.content;
      const timestamp = new Date(payload.timestamp);
      
      // Special handling for system messages
      if (comedian === 'system') {
        console.log('System message:', content);
      }
      
      addMessageToConversation(comedian, content, timestamp);
      break;
      
    case 'start':
      console.log('Comedy generation started:', payload);
      if (payload.topic) {
        currentTopicBadge.textContent = payload.topic;
      }
      showLoading();
      break;
      
    case 'complete':
      console.log('Comedy generation completed');
      hideLoading();
      break;
      
    case 'error':
      console.error('Error message:', payload);
      displayErrorMessage(payload.error);
      hideLoading();
      break;
      
    default:
      console.log('Unknown message type:', messageType);
  }
}

function startComedyConversation() {
  if (!isConnected) {
    displayErrorMessage('Not connected to the server. Please refresh the page and try again.');
    return;
  }
  
  // Get selected topic
  let topic = topicSelect.value;
  if (!topic) {
    displayErrorMessage('Please select a topic');
    return;
  }
  
  // Check if custom topic is selected
  if (topic === 'custom') {
    const customTopic = customTopicInput.value.trim();
    if (!customTopic) {
      displayErrorMessage('Please enter a custom topic');
      return;
    }
    topic = customTopic;
  }
  
  // Get selected style
  const style = styleSelect.value;
  
  // Clear the conversation
  clearConversation();
  
  // Update the current topic badge
  currentTopicBadge.textContent = topic;
  
  // Create the start message
  const startMessage = {
    type: 'start',
    payload: {
      topic: topic,
      maxTurns: turns,
      style: style
    }
  };
  
  console.log('Starting conversation with topic:', topic);
  
  // Send the message
  try {
    socket.send(JSON.stringify(startMessage));
    console.log('Start message sent successfully');
  } catch (error) {
    console.error('Error sending start message:', error);
    displayErrorMessage('Failed to start conversation. Please try again.');
  }
}

function resetConversation() {
  clearConversation();
  displayWelcomeMessage();
  currentTopicBadge.textContent = 'Select a topic';
  hideLoading();
}

// Setup event listeners
function setupEventListeners() {
  // Start button
  startButton.addEventListener('click', startComedyConversation);
  
  // Reset button
  resetButton.addEventListener('click', resetConversation);
  
  // Turn count buttons
  decreaseTurnsButton.addEventListener('click', () => {
    if (turns > 1) {
      turns--;
      turnsDisplay.textContent = turns;
    }
  });
  
  increaseTurnsButton.addEventListener('click', () => {
    if (turns < 10) {
      turns++;
      turnsDisplay.textContent = turns;
    }
  });
  
  // Audience reactions
  document.querySelectorAll('.reaction').forEach(reaction => {
    reaction.addEventListener('click', (e) => {
      const rect = reaction.getBoundingClientRect();
      const x = rect.left + rect.width / 2;
      const y = rect.top;
      
      // Create a floating reaction
      const floatingEmoji = document.createElement('div');
      floatingEmoji.className = 'floating-reaction';
      floatingEmoji.textContent = reaction.textContent;
      floatingEmoji.style.left = `${x}px`;
      floatingEmoji.style.top = `${y}px`;
      
      document.body.appendChild(floatingEmoji);
      
      // Remove after animation completes
      setTimeout(() => {
        document.body.removeChild(floatingEmoji);
      }, 1500);
    });
  });
}

// Initialize the application
function initApp() {
  console.log('Initializing application...');
  
  // Set initial state
  displayWelcomeMessage();
  updateAudienceCount();
  
  // Set up listeners
  setupEventListeners();
  
  // Connect to WebSocket
  connectWebSocket();
  
  // Update audience count periodically
  setInterval(updateAudienceCount, 10000);
}

// Start the app when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', initApp);