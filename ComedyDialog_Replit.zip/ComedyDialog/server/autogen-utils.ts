import { startComedyConversation } from './comedy';
import { IStorage } from './storage';

/**
 * Generates a comedy conversation using AutoGen and streams results via callback
 * @param topic The topic of conversation
 * @param maxTurns Maximum number of turns in the conversation
 * @param storage Storage instance to save the conversation
 * @param onMessageCallback Optional callback for streaming messages
 * @returns Promise<number> The conversation ID
 */
export async function generateComedyConversation(
  topic: string,
  maxTurns: number = 5,
  storage: IStorage,
  onMessageCallback?: (comedian: string, message: string) => void
): Promise<number> {
  try {
    // Start the comedy conversation
    const result = await startComedyConversation(
      topic, 
      maxTurns, 
      'observational',
      onMessageCallback
    );
    
    // Save the conversation to storage
    const savedConversation = await storage.saveComedyConversation({
      topic,
      style: 'observational',
      messages: result.messages,
      timestamp: new Date(),
    });
    
    // Send the completion message via callback if provided
    if (onMessageCallback) {
      onMessageCallback('system', 'Comedy conversation completed!');
    }
    
    // Return the conversation ID
    return savedConversation.id;
  } catch (error) {
    console.error('Error generating comedy conversation:', error);
    throw error;
  }
}