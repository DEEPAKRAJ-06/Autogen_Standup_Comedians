import { conversationHistory, insertConversationSchema, type StoredComedyConversation, type InsertComedyConversation } from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  getUser(id: number): Promise<any | undefined>;
  getUserByUsername(username: string): Promise<any | undefined>;
  createUser(user: any): Promise<any>;
  saveComedyConversation(conversation: InsertComedyConversation): Promise<StoredComedyConversation>;
  getComedyHistory(): Promise<StoredComedyConversation[]>;
  getConversationById(id: number): Promise<StoredComedyConversation | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, any>;
  private comedyConversations: Map<number, StoredComedyConversation>;
  currentUserId: number;
  currentConversationId: number;

  constructor() {
    this.users = new Map();
    this.comedyConversations = new Map();
    this.currentUserId = 1;
    this.currentConversationId = 1;
  }

  async getUser(id: number): Promise<any | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<any | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: any): Promise<any> {
    const id = this.currentUserId++;
    const user = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async saveComedyConversation(insertConversation: InsertComedyConversation): Promise<StoredComedyConversation> {
    const id = this.currentConversationId++;
    
    // Type safety for message conversion
    const messagesArray = Array.isArray(insertConversation.messages) 
      ? insertConversation.messages.map((m: any) => ({
          speaker: m.speaker as string,
          message: m.message as string
        }))
      : [];
      
    const conversation: StoredComedyConversation = { 
      id,
      topic: insertConversation.topic,
      style: insertConversation.style,
      messages: messagesArray,
      timestamp: insertConversation.timestamp
    };
    
    this.comedyConversations.set(id, conversation);
    return conversation;
  }

  async getComedyHistory(): Promise<StoredComedyConversation[]> {
    return Array.from(this.comedyConversations.values())
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  async getConversationById(id: number): Promise<StoredComedyConversation | undefined> {
    return this.comedyConversations.get(id);
  }
}

export const storage = new MemStorage();
