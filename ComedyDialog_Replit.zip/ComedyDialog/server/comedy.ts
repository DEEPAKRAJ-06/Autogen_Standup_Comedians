import { exec, spawn } from 'child_process';
import { promisify } from 'util';
import * as fs from 'fs';
import * as path from 'path';
import { storage } from './storage';

// Promisify the exec function
const execPromise = promisify(exec);

// Function to generate the OAI_CONFIG_LIST file for AutoGen
function generateOAIConfigList(): string {
  const configList = [
    {
      model: "gemini-2.0-flash",
      api_key: process.env.GOOGLE_API_KEY,
      api_type: "google"
    }
  ];
  
  return JSON.stringify(configList, null, 4);
}

// Function to generate Python script for comedy conversation using direct Gemini API
function createPythonScript(topic: string, maxTurns: number, style: string): string {
  return `
import json
import sys
import os
import google.generativeai as genai
from typing import Dict, List, Any

try:
    # Set up Gemini API
    GOOGLE_API_KEY = os.environ.get("GOOGLE_API_KEY")
    if not GOOGLE_API_KEY:
        raise ValueError("GOOGLE_API_KEY environment variable is not set")
        
    genai.configure(api_key=GOOGLE_API_KEY)

    # Initialize the model
    model = genai.GenerativeModel(model_name="gemini-1.5-flash")

    # Define the comedians and their personalities
    comedians = {
        "cathy": {
            "name": "Cathy",
            "personality": "Indian stand-up comedian who keeps jokes like a natural conversation rather than cringy jokes. Uses ${style} comedy style."
        },
        "joe": {
            "name": "Joe",
            "personality": "Indian stand-up comedian who builds on the punchlines of previous jokes. Uses ${style} comedy style."
        }
    }

    # Start the conversation
    conversation = [
        {
            "speaker": "joe",
            "message": f"Hey Cathy, let's start our comedy routine about ${topic}. I'll kick things off!"
        }
    ]

    # Function to generate the next response in the conversation
    def generate_comedy_response(current_speaker, other_speaker, conversation_history, topic):
        # Context for the AI
        prompt = f"""
You are {comedians[current_speaker]['name']}, {comedians[current_speaker]['personality']}
You're performing a stand-up comedy routine with {comedians[other_speaker]['name']} about {topic}.
The conversation so far:

"""
        # Add conversation history to the prompt
        for msg in conversation_history:
            prompt += f"{comedians[msg['speaker']]['name']}: {msg['message']}\\n"
        
        prompt += f"\\nNow continue as {comedians[current_speaker]['name']}. Keep your response concise (under 100 words) and funny. Don't explain the joke."
        
        # Generate response from Gemini
        try:
            response = model.generate_content(prompt)
            
            # Clean up the response to remove the name prefix if it exists
            message = response.text.strip()
            name_prefix = f"{comedians[current_speaker]['name']}: "
            if message.startswith(name_prefix):
                message = message[len(name_prefix):].strip()
                
            return message
        except Exception as e:
            print(f"Error generating response: {str(e)}", file=sys.stderr)
            return f"Sorry, I'm having a creative block about {topic}..."

    # Generate the conversation
    current_turn = 0
    max_turns = ${maxTurns}

    # Alternate between comedians
    while current_turn < max_turns:
        # Cathy's turn
        cathy_response = generate_comedy_response(
            current_speaker="cathy", 
            other_speaker="joe", 
            conversation_history=conversation,
            topic="${topic}"
        )
        conversation.append({"speaker": "cathy", "message": cathy_response})
        
        if current_turn < max_turns - 1:  # Check if Joe should respond
            # Joe's turn
            joe_response = generate_comedy_response(
                current_speaker="joe", 
                other_speaker="cathy", 
                conversation_history=conversation,
                topic="${topic}"
            )
            conversation.append({"speaker": "joe", "message": joe_response})
        
        current_turn += 1
    
    # Output only the result JSON object and nothing else
    result = {"messages": conversation}
    print(json.dumps(result), end="")
    
except Exception as e:
    # In case of error, output a valid JSON with error details
    error_result = {"error": str(e)}
    print(json.dumps(error_result), file=sys.stderr)
    sys.exit(1)

# Output is already handled in the try block above
# No additional processing needed here
`;
}

// Interface for the response from the Python script
interface ComedyResponse {
  messages: Array<{
    speaker: "cathy" | "joe";
    message: string;
  }>;
}

// Function to run Python script and return promise
function runPythonScript(scriptPath: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const python = spawn('python', [scriptPath]);
    
    let dataString = '';
    let errorString = '';

    python.stdout.on('data', (data) => {
      dataString += data.toString();
    });

    python.stderr.on('data', (data) => {
      errorString += data.toString();
      console.error(`Python stderr: ${data}`);
    });

    python.on('close', (code) => {
      if (code !== 0) {
        reject(new Error(`Python process exited with code ${code}: ${errorString}`));
      } else {
        resolve(dataString);
      }
    });
  });
}

// Function to start a comedy conversation
export async function startComedyConversation(
  topic: string,
  maxTurns: number = 5,
  style: string = 'observational',
  onMessageCallback?: (comedian: string, message: string) => void
): Promise<ComedyResponse> {
  try {
    console.log(`Generating comedy conversation for topic: ${topic}`);
    
    // Change to false for mock data, true for actual Python execution with Gemini API
    const useMockData = false;
    
    let result: ComedyResponse;
    
    if (useMockData) {
      // Mock execution for testing purposes
      const mockMessages = [
        {
          speaker: "joe" as const,
          message: `Hey Cathy, let's start our comedy routine about ${topic}. I'll kick things off!`
        },
        {
          speaker: "cathy" as const,
          message: `So I was thinking about ${topic} the other day. It's fascinating how we all get caught up in it, isn't it?`
        },
        {
          speaker: "joe" as const,
          message: `Yeah, when you mentioned ${topic}, I immediately thought about my last vacation. Talk about a disaster!`
        },
        {
          speaker: "cathy" as const,
          message: "Speaking of disasters, my attempt at cooking last night would qualify for emergency funding."
        },
        {
          speaker: "joe" as const,
          message: "Your cooking reminds me of my dating life - lots of smoke, some fire alarms, and everyone running away!"
        }
      ];
      
      // Call the callback for each message if provided, simulating real-time generation
      if (onMessageCallback) {
        console.log("Sending mock messages via callback...");
        for (const message of mockMessages) {
          await new Promise(resolve => setTimeout(resolve, 1000)); // 1 second delay
          onMessageCallback(message.speaker, message.message);
        }
      }
      
      result = { messages: mockMessages };
    } else {
      // Create temporary directory for the Python script and config
      const tempDir = path.join(process.cwd(), 'temp');
      if (!fs.existsSync(tempDir)) {
        fs.mkdirSync(tempDir, { recursive: true });
      }
      
      // Generate OAI_CONFIG_LIST file with Gemini API configuration
      const configPath = path.join(tempDir, 'OAI_CONFIG_LIST');
      fs.writeFileSync(configPath, generateOAIConfigList());
      
      // Create Python script
      const scriptPath = path.join(tempDir, `comedy_${Date.now()}.py`);
      const pythonScript = createPythonScript(topic, maxTurns, style);
      fs.writeFileSync(scriptPath, pythonScript);
      
      console.log(`Executing AutoGen Python script for topic: ${topic}`);
      try {
        // Run the Python script
        const output = await runPythonScript(scriptPath);
        result = JSON.parse(output) as ComedyResponse;
        
        // Call the callback for each message if provided
        if (onMessageCallback && Array.isArray(result.messages)) {
          console.log("Sending generated messages via callback...");
          for (const message of result.messages) {
            await new Promise(resolve => setTimeout(resolve, 1000)); // 1 second delay
            onMessageCallback(message.speaker, message.message);
          }
        }
        
        // Clean up the temporary script file
        try {
          fs.unlinkSync(scriptPath);
        } catch (err) {
          console.warn("Could not delete temporary script file:", err);
        }
      } catch (pythonError: any) {
        console.error("Error running Python script:", pythonError);
        const errorMessage = pythonError?.message || String(pythonError);
        throw new Error(`Failed to generate comedy conversation: ${errorMessage}`);
      }
    }
    
    console.log(`Generated comedy conversation with ${result.messages.length} messages`);
    return result;
  } catch (error) {
    console.error("Error generating comedy conversation:", error);
    throw error;
  }
}