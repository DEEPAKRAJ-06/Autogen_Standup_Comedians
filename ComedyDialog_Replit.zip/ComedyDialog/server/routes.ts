import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from "ws";
import { storage } from "./storage";
import { startComedyConversation } from "./comedy";
import { setupWebSocketServer } from "./websocket";

export async function registerRoutes(app: Express): Promise<Server> {
  // Comedy conversation API endpoint
  app.post("/api/comedy/conversation", async (req, res) => {
    try {
      const { topic, turns, style } = req.body;
      
      if (!topic) {
        return res.status(400).json({ message: "Topic is required" });
      }
      
      // Default values if not provided
      const maxTurns = turns || 4;
      const comedyStyle = style || "observational";
      
      // Generate comedy conversation
      const result = await startComedyConversation(topic, maxTurns, comedyStyle);
      
      // Save conversation to storage
      const savedConversation = await storage.saveComedyConversation({
        topic,
        style: comedyStyle,
        messages: result.messages,
        timestamp: new Date(),
      });
      
      return res.status(200).json(result);
    } catch (error) {
      console.error("Error generating comedy conversation:", error);
      return res.status(500).json({ 
        message: "Failed to generate comedy conversation",
        error: (error as Error).message
      });
    }
  });

  // Get past comedy conversations
  app.get("/api/comedy/history", async (req, res) => {
    try {
      const history = await storage.getComedyHistory();
      return res.status(200).json(history);
    } catch (error) {
      console.error("Error fetching comedy history:", error);
      return res.status(500).json({ 
        message: "Failed to fetch comedy history",
        error: (error as Error).message
      });
    }
  });

  const httpServer = createServer(app);
  
  // Create WebSocket server for real-time comedy
  const wss = new WebSocketServer({ 
    server: httpServer,
    path: '/ws/comedy'
  });
  
  // Setup WebSocket handlers
  setupWebSocketServer(wss);
  
  return httpServer;
}
