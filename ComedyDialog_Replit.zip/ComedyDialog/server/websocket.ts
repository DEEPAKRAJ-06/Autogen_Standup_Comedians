import { WebSocketServer, WebSocket } from 'ws';
import { StoredComedyConversation, WebSocketMessage } from '@shared/schema';
import { storage } from './storage';
import { generateComedyConversation } from './autogen-utils';

// WebSocket client type with connection identification
interface WebSocketClient extends WebSocket {
  id: string;
  conversationId?: number;
  isAlive: boolean; // For ping/pong heartbeat
}

// Setup WebSocket server with improved error handling
export function setupWebSocketServer(wss: WebSocketServer) {
  // Configure WebSocket server options
  wss.options.maxPayload = 1024 * 1024; // 1MB max payload
  
  // Keep track of clients by conversation
  const clientsByConversation = new Map<number, Set<WebSocketClient>>();
  
  // Heartbeat to keep connections alive and detect stale connections
  const interval = setInterval(() => {
    wss.clients.forEach((ws) => {
      const client = ws as WebSocketClient;
      
      if (!client.isAlive) {
        console.log(`Terminating inactive client: ${client.id || 'unknown'}`);
        return client.terminate();
      }
      
      client.isAlive = false;
      
      try {
        client.ping();
      } catch (err) {
        console.error('Error sending ping:', err);
        client.terminate();
      }
    });
  }, 30000); // 30 seconds
  
  // Stop the heartbeat interval when the server closes
  wss.on('close', () => {
    clearInterval(interval);
  });
  
  // Handle new connections
  wss.on('connection', (ws: WebSocketClient) => {
    // Initialize client properties
    ws.id = Math.random().toString(36).substring(2, 15);
    ws.isAlive = true;
    console.log(`Client connected: ${ws.id}`);
    
    // Respond to pong messages (heartbeat)
    ws.on('pong', () => {
      ws.isAlive = true;
    });
    
    // Send message to the client with error handling
    const sendMessage = (message: WebSocketMessage) => {
      if (ws.readyState === WebSocket.OPEN) {
        try {
          const messageJson = JSON.stringify(message);
          console.log(`Sending message to client ${ws.id}:`, 
            messageJson.length > 100 ? `${messageJson.substring(0, 100)}...` : messageJson);
          ws.send(messageJson);
        } catch (error) {
          console.error(`Error sending message to client ${ws.id}:`, error);
        }
      } else {
        console.warn(`Cannot send message to client ${ws.id} - connection not open`);
      }
    };
    
    // Handle messages from clients
    ws.on('message', async (data) => {
      console.log(`Received message from client ${ws.id}`);
      
      try {
        // Parse the message
        let messageStr: string;
        if (Buffer.isBuffer(data)) {
          messageStr = data.toString('utf8');
        } else if (typeof data === 'string') {
          messageStr = data;
        } else if (Array.isArray(data)) {
          messageStr = Buffer.concat(data).toString('utf8');
        } else {
          throw new Error('Unsupported message format');
        }
        
        const message = JSON.parse(messageStr) as WebSocketMessage;
        console.log(`Parsed message type: ${message.type}`);
        
        if (message.type === 'start') {
          // Start a new comedy conversation
          const { topic, maxTurns = 5, customTopic } = message.payload || {};
          
          if (!topic) {
            throw new Error('Missing topic in start message');
          }
          
          const actualTopic = customTopic && customTopic.trim() ? customTopic : topic;
          console.log(`Starting conversation about topic: ${actualTopic}`);
          
          // Define callback for new messages
          const onNewMessage = (comedian: string, content: string) => {
            console.log(`New message from ${comedian}: ${content.substring(0, 50)}...`);
            
            // Send message to the current client first (for quicker feedback)
            if (ws.readyState === WebSocket.OPEN) {
              try {
                ws.send(JSON.stringify({
                  type: 'message',
                  payload: {
                    comedian,
                    content,
                    conversationId: ws.conversationId,
                    timestamp: new Date()
                  }
                }));
              } catch (error) {
                console.error(`Error sending message to initiating client ${ws.id}:`, error);
              }
            }
            
            // Get all other clients subscribed to this conversation
            const clients = clientsByConversation.get(ws.conversationId!) || new Set<WebSocketClient>();
            
            // Send message to all other clients
            clients.forEach(client => {
              // Skip the initiating client as we've already sent to them
              if (client.id === ws.id) return;
              
              if (client.readyState === WebSocket.OPEN) {
                try {
                  client.send(JSON.stringify({
                    type: 'message',
                    payload: {
                      comedian,
                      content,
                      conversationId: ws.conversationId,
                      timestamp: new Date()
                    }
                  }));
                } catch (error) {
                  console.error(`Error sending message to client ${client.id}:`, error);
                }
              }
            });
          };
          
          try {
            // Send acknowledgment that we're starting
            sendMessage({
              type: 'start',
              payload: { status: 'generating', topic: actualTopic }
            });
            
            // Start generating the conversation
            const conversationId = await generateComedyConversation(
              actualTopic,
              maxTurns,
              storage,
              onNewMessage
            );
            
            // Save conversation ID to client
            ws.conversationId = conversationId;
            
            // Add client to the conversation subscribers list
            if (!clientsByConversation.has(conversationId)) {
              clientsByConversation.set(conversationId, new Set());
            }
            clientsByConversation.get(conversationId)!.add(ws);
            
            // Let client know the conversation has started successfully
            sendMessage({
              type: 'start',
              payload: { conversationId, topic: actualTopic, status: 'ready' }
            });
          } catch (error) {
            console.error('Error starting conversation:', error);
            sendMessage({
              type: 'error',
              payload: { error: 'Failed to start conversation: ' + (error instanceof Error ? error.message : String(error)) }
            });
          }
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
        sendMessage({
          type: 'error',
          payload: { error: 'Invalid message format: ' + (error instanceof Error ? error.message : String(error)) }
        });
      }
    });
    
    // Handle client errors
    ws.on('error', (error) => {
      console.error(`WebSocket error for client ${ws.id}:`, error);
    });
    
    // Handle client disconnection
    ws.on('close', (code, reason) => {
      console.log(`Client disconnected: ${ws.id}, Code: ${code}, Reason: ${reason}`);
      
      // Remove client from all conversation subscribers
      if (ws.conversationId && clientsByConversation.has(ws.conversationId)) {
        clientsByConversation.get(ws.conversationId)!.delete(ws);
        
        // Clean up empty subscription sets
        if (clientsByConversation.get(ws.conversationId)!.size === 0) {
          clientsByConversation.delete(ws.conversationId);
        }
      }
    });
    
    // Send a welcome message to the client
    sendMessage({
      type: 'message',
      payload: { 
        comedian: 'system',
        content: 'Welcome to the AI Comedy Club! Select a topic to start a comedy conversation.',
        timestamp: new Date()
      }
    });
  });
  
  // Log server errors
  wss.on('error', (error) => {
    console.error('WebSocket server error:', error);
  });
  
  console.log('WebSocket server set up successfully');
  return wss;
}
