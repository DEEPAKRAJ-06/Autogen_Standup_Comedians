import os
import sys
from fastapi import FastAPI, WebSocket, HTTPException, WebSocketDisconnect, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import json
import asyncio
import subprocess
import time
import logging
from datetime import datetime

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI()

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify actual origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files directory
app.mount("/static", StaticFiles(directory="server/static"), name="static")

# Store active WebSocket connections
active_connections: List[WebSocket] = []

# Store comedy conversations
comedy_conversations = {}

class ComedyRequest(BaseModel):
    topic: str
    max_turns: int = 5
    style: str = "observational"

class ComedyMessage(BaseModel):
    speaker: str
    message: str

class ComedyResponse(BaseModel):
    messages: List[ComedyMessage]

class ErrorResponse(BaseModel):
    error: str

# WebSocket connection manager
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info(f"New WebSocket connection. Total connections: {len(self.active_connections)}")

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
            logger.info(f"WebSocket disconnected. Remaining connections: {len(self.active_connections)}")

    async def broadcast(self, message: Dict[str, Any]):
        for connection in self.active_connections:
            await connection.send_text(json.dumps(message))

    async def send_personal_message(self, message: Dict[str, Any], websocket: WebSocket):
        await websocket.send_text(json.dumps(message))

manager = ConnectionManager()

# Helper function to run the AutoGen script
def run_autogen_script(topic: str, max_turns: int, style: str):
    try:
        # Path to the user's attached AutoGen notebook or script
        notebook_path = "./attached_assets/L1_Multi-Agent_Conversation_and_Stand-up_Comedy.ipynb"
        
        # Prepare the command to execute - run the notebook with papermill or use a Python script
        # This is a placeholder - replace with actual execution logic based on your AutoGen implementation
        cmd = [
            "python", "-c", 
            f"""
import os
import json
import sys
import autogen
from datetime import datetime

# Set the topic and other parameters
topic = '{topic}'
max_turns = {max_turns}
style = '{style}'

# Configure the AutoGen agents
config_list = autogen.config_list_from_json('./attached_assets/OAI_CONFIG_LIST')

# Define the comedians
cathy = autogen.ConversableAgent(
    name="cathy",
    system_message=f"Your name is Cathy and you are an Indian stand-up comedian. Keep the jokes like a natural conversation rather than cringy jokes. The standup comedy show should be on the topic of {topic}. Use {style} comedy style. When you're ready to end the conversation, say 'I gotta go'.,
    llm_config={{"config_list": config_list}},
    human_input_mode="NEVER",
)

joe = autogen.ConversableAgent(
    name="joe",
    system_message=f"Your name is Joe and you are an Indian stand-up comedian. The comedy show is about {topic}. Use {style} comedy style. Start the next joke from the punchline of the previous joke.When you're ready to end the conversation, say 'I gotta go'.",
    llm_config={{"config_list": config_list}},
    human_input_mode="NEVER",
)

# Start the conversation
try:
    chat_result = joe.initiate_chat(
        recipient=cathy, 
        message=f"Hey Cathy, let's start our comedy routine about {topic}. I'll kick things off!",
        max_turns=max_turns,
    )

    # Extract messages from the conversation
    messages = []
    for msg in cathy.chat_messages[joe]:
        if msg["role"] == "user":
            messages.append({{"speaker": "joe", "message": msg["content"]}})
    for msg in joe.chat_messages[cathy]:
        if msg["role"] == "user":
            messages.append({{"speaker": "cathy", "message": msg["content"]}})

    # Sort messages by their index in the conversation
    sorted_messages = []
    msg_index = 0
    total_msgs = len(messages)
    while msg_index < total_msgs:
        if msg_index < len(joe.chat_messages[cathy]):
            joe_msg = joe.chat_messages[cathy][msg_index]
            if joe_msg["role"] == "user":
                sorted_messages.append({{"speaker": "joe", "message": joe_msg["content"]}})
        
        if msg_index < len(cathy.chat_messages[joe]):
            cathy_msg = cathy.chat_messages[joe][msg_index]
            if cathy_msg["role"] == "user":
                sorted_messages.append({{"speaker": "cathy", "message": cathy_msg["content"]}})
        
        msg_index += 1

    # Output the results
    result = {{"messages": sorted_messages}}
    print(json.dumps(result))
except Exception as e:
    print(json.dumps({{"error": str(e)}}))
            """
        ]
        
        # Execute the command
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate()
        
        # Check for errors
        if process.returncode != 0:
            error_message = stderr.decode('utf-8')
            logger.error(f"Error running AutoGen script: {error_message}")
            return {"error": f"Failed to generate comedy conversation: {error_message}"}
        
        # Parse the output
        result = json.loads(stdout.decode('utf-8'))
        return result
        
    except Exception as e:
        logger.error(f"Exception running AutoGen script: {str(e)}")
        return {"error": f"Error generating comedy: {str(e)}"}

@app.get("/", response_class=HTMLResponse)
async def root():
    # Return the HTML file
    with open("index.html", "r") as f:
        html_content = f.read()
    return HTMLResponse(content=html_content, status_code=200)

@app.post("/api/comedy")
async def create_comedy(request: ComedyRequest):
    try:
        # Run the AutoGen script
        logger.info(f"Generating comedy for topic: {request.topic}")
        result = run_autogen_script(request.topic, request.max_turns, request.style)
        
        # Check for errors
        if "error" in result:
            raise HTTPException(status_code=500, detail=result["error"])
        
        # Store the conversation
        conversation_id = len(comedy_conversations) + 1
        comedy_conversations[conversation_id] = {
            "id": conversation_id,
            "topic": request.topic,
            "messages": result["messages"],
            "created_at": datetime.now().isoformat(),
            "is_complete": True
        }
        
        return result
    
    except Exception as e:
        logger.error(f"Error in /api/comedy: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/comedy/history")
async def get_comedy_history():
    return list(comedy_conversations.values())

@app.get("/api/comedy/{conversation_id}")
async def get_comedy_conversation(conversation_id: int):
    if conversation_id not in comedy_conversations:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return comedy_conversations[conversation_id]

@app.websocket("/ws/comedy")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    
    try:
        # Send welcome message
        await manager.send_personal_message({
            "type": "message",
            "payload": {
                "comedian": "system",
                "content": "Welcome to the AI Comedy Club! Select a topic to start a comedy conversation.",
                "timestamp": datetime.now().isoformat()
            }
        }, websocket)
        
        while True:
            # Wait for messages from the client
            data = await websocket.receive_text()
            message = json.loads(data)
            
            # Handle different message types
            if message["type"] == "start":
                # Extract parameters
                topic = message["payload"].get("topic", "Comedy")
                max_turns = message["payload"].get("maxTurns", 5)
                style = message["payload"].get("style", "observational")
                
                # Acknowledge receipt
                await manager.send_personal_message({
                    "type": "start",
                    "payload": {
                        "status": "generating",
                        "topic": topic
                    }
                }, websocket)
                
                # Start a task to generate comedy
                try:
                    logger.info(f"Starting comedy generation for topic: {topic}")
                    result = run_autogen_script(topic, max_turns, style)
                    
                    # Check for errors
                    if "error" in result:
                        await manager.send_personal_message({
                            "type": "error",
                            "payload": {
                                "error": result["error"]
                            }
                        }, websocket)
                        continue
                    
                    # Stream the messages back with delay
                    for idx, message in enumerate(result["messages"]):
                        await asyncio.sleep(1)  # Add delay between messages
                        await manager.send_personal_message({
                            "type": "message",
                            "payload": {
                                "comedian": message["speaker"],
                                "content": message["message"],
                                "timestamp": datetime.now().isoformat()
                            }
                        }, websocket)
                    
                    # Signal completion
                    await manager.send_personal_message({
                        "type": "complete",
                        "payload": {
                            "topic": topic,
                            "messageCount": len(result["messages"])
                        }
                    }, websocket)
                    
                except Exception as e:
                    logger.error(f"Error generating comedy: {str(e)}")
                    await manager.send_personal_message({
                        "type": "error",
                        "payload": {
                            "error": f"Failed to generate comedy: {str(e)}"
                        }
                    }, websocket)
            
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    
    except Exception as e:
        logger.error(f"WebSocket error: {str(e)}")
        manager.disconnect(websocket)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("fastapi_server:app", host="0.0.0.0", port=5100, reload=True)