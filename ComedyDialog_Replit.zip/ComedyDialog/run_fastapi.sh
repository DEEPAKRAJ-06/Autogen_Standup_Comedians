#!/bin/bash

# Run the FastAPI server
cd "$(dirname "$0")"
echo "Starting FastAPI server for AI Comedy Club..."
python -m uvicorn server.fastapi_server:app --host 0.0.0.0 --port 5000 --reload