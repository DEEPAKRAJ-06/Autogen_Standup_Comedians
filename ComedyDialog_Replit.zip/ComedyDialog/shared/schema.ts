import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Comedy message for displaying in UI
export interface ComedyMessage {
  id: number | string;
  comedian: string;
  content: string;
  timestamp: Date;
}

// Comedy conversation for frontend
export interface ComedyConversation {
  id: number;
  topic: string;
  messages: ComedyMessage[];
  createdAt: Date;
  isComplete: boolean;
}

// WebSocket message types
export type WebSocketMessageType = 'start' | 'message' | 'complete' | 'error';

export interface WebSocketMessage {
  type: WebSocketMessageType;
  payload: any;
}

// Comedy request form schema
export const comedyRequestSchema = z.object({
  topic: z.string(),
  maxTurns: z.number().int().min(1).max(20).default(5),
  customTopic: z.string().optional(),
});

// Define the comedy conversation table - only for storage
export const conversationHistory = pgTable("conversation_history", {
  id: serial("id").primaryKey(),
  topic: text("topic").notNull(),
  style: text("style").notNull(),
  messages: jsonb("messages").$type<{speaker: string, message: string}[]>().notNull(),
  timestamp: timestamp("timestamp").notNull(),
});

// Create the insert schema
export const insertConversationSchema = createInsertSchema(conversationHistory).pick({
  topic: true,
  style: true,
  messages: true,
  timestamp: true,
});

export type InsertComedyConversation = z.infer<typeof insertConversationSchema>;
export type StoredComedyConversation = typeof conversationHistory.$inferSelect;
