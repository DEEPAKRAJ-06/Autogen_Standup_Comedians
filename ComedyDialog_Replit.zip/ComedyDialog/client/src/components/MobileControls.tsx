import React from 'react';

interface MobileControlsProps {
  onProfilesToggle: () => void;
  onControlsToggle: () => void;
  onStart: () => void;
  isLoading: boolean;
  showControls: boolean;
  onCloseControls: () => void;
}

export default function MobileControls({
  onProfilesToggle,
  onControlsToggle,
  onStart,
  isLoading,
  showControls,
  onCloseControls
}: MobileControlsProps) {
  return (
    <>
      {/* Mobile fixed controls at bottom */}
      <div className="fixed bottom-0 left-0 right-0 flex items-center justify-between bg-black/80 border-t border-gray-800 p-3 lg:hidden z-40">
        <button
          onClick={onProfilesToggle}
          className="flex items-center justify-center text-gray-300 hover:text-white"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="7" r="4" />
            <path d="M5 22v-4a7 7 0 0 1 14 0v4" />
          </svg>
          <span className="ml-2">Comedians</span>
        </button>
        
        <button
          onClick={onStart}
          disabled={isLoading}
          className="bg-yellow-500 hover:bg-yellow-600 text-black font-medium py-2 px-4 rounded-md flex items-center"
        >
          {isLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-black" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Generating...
            </>
          ) : (
            <>Start Comedy</>
          )}
        </button>
        
        <button
          onClick={onControlsToggle}
          className="flex items-center justify-center text-gray-300 hover:text-white"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="3"></circle>
            <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
          </svg>
          <span className="ml-2">Settings</span>
        </button>
      </div>
      
      {/* Mobile controls panel overlay */}
      {showControls && (
        <div className="fixed inset-0 z-50 flex items-end justify-center lg:hidden">
          <div className="absolute inset-0 bg-black/60" onClick={onCloseControls}></div>
          <div className="relative bg-black/90 border border-gray-800 rounded-t-xl w-full max-w-md px-5 py-6 animate-slideUp">
            <button 
              className="absolute top-3 right-3 text-gray-400"
              onClick={onCloseControls}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </button>
            
            <h3 className="text-xl font-medium text-yellow-400 mb-4">Comedy Settings</h3>
            
            <div className="space-y-4">
              {/* Content of the controls panel would go here */}
              <p className="text-gray-300">Mobile settings panel content would go here. This could include topic selection, theme toggles, etc.</p>
              
              <button
                onClick={onStart}
                disabled={isLoading}
                className="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-medium py-3 px-4 rounded-md flex items-center justify-center"
              >
                Start New Comedy Show
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}