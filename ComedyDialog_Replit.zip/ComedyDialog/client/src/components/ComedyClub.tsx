import { useState, useEffect } from "react";
import ComedyStage from "@/components/ComedyStage";
import ComedianProfile from "@/components/ComedianProfile";
import ControlPanel from "@/components/ControlPanel";
import MobileControls from "./MobileControls";
import { useToast } from "@/hooks/use-toast";
import { useComedy } from "@/hooks/use-comedy";
import { useMediaQuery } from "@/hooks/use-mobile";

export function ComedyClub() {
  const { toast } = useToast();
  const isMobile = useMediaQuery("(max-width: 1024px)");
  const [showMobileProfiles, setShowMobileProfiles] = useState(false);
  const [showMobileControls, setShowMobileControls] = useState(false);
  
  const {
    conversation,
    isLoading,
    error,
    startConversation,
    resetConversation,
    currentTopic
  } = useComedy();

  // Handle connection errors
  useEffect(() => {
    if (error) {
      toast({
        title: "Connection Error",
        description: "Could not connect to the comedy server. Please try again.",
        variant: "destructive",
      });
    }
  }, [error, toast]);

  // Handle mobile toggles
  const handleMobileProfilesToggle = () => {
    setShowMobileProfiles(!showMobileProfiles);
    setShowMobileControls(false);
  };

  const handleMobileControlsToggle = () => {
    setShowMobileControls(!showMobileControls);
    setShowMobileProfiles(false);
  };

  return (
    <div className="flex flex-col lg:flex-row min-h-screen">
      {/* Left Sidebar - Show on desktop or when toggled on mobile */}
      <aside className={`lg:w-1/4 bg-black/70 p-4 lg:p-6 flex flex-col ${
        !isMobile || showMobileProfiles ? "block" : "hidden"
      } ${isMobile ? "fixed inset-0 z-50 overflow-y-auto" : ""}`}>
        <div className="mb-8">
          <h1 className="text-3xl text-yellow-400 mb-1">AI Comedy Club</h1>
          <p className="text-blue-300 text-lg">AutoGen Standup</p>
        </div>
        
        {/* Close button for mobile view */}
        {isMobile && showMobileProfiles && (
          <button 
            className="absolute top-4 right-4 text-white"
            onClick={() => setShowMobileProfiles(false)}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        )}
        
        <ComedianProfile
          name="cathy"
          displayName="Cathy"
          avatarUrl="https://images.unsplash.com/photo-1494790108377-be9c29b29330"
          title="Observational Comedy Specialist"
          description="Your name is Cathy and you are an Indian stand-up comedian. Keep the jokes like a natural conversation rather than cringy jokes."
        />
        
        <ComedianProfile
          name="joe"
          displayName="Joe"
          avatarUrl="https://images.unsplash.com/photo-1566492031773-4f4e44671857"
          title="Improvisational Comedy Expert"
          description="Your name is Joe and you are an Indian stand-up comedian. Start the next joke from the punchline of the previous joke."
        />
        
        {/* Control Panel - Show on desktop or when not in mobile profiles view */}
        {(!isMobile || !showMobileProfiles) && (
          <ControlPanel
            onStart={startConversation}
            onReset={resetConversation}
            isLoading={isLoading}
          />
        )}
      </aside>

      {/* Main Content Area - Comedy Stage */}
      <ComedyStage
        conversation={conversation}
        isLoading={isLoading}
        hasError={!!error}
        currentTopic={currentTopic}
        onRetry={() => startConversation(currentTopic)}
      />

      {/* Mobile Controls */}
      {isMobile && (
        <MobileControls
          onProfilesToggle={handleMobileProfilesToggle}
          onControlsToggle={handleMobileControlsToggle}
          onStart={() => startConversation(currentTopic)}
          isLoading={isLoading}
          showControls={showMobileControls}
          onCloseControls={() => setShowMobileControls(false)}
        />
      )}
    </div>
  );
}