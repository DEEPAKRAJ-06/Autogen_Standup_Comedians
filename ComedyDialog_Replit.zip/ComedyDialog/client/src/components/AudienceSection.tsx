import React from "react";
import { UsersIcon, CalendarIcon } from "@/assets/icons";

export function AudienceSection() {
  // Audience SVG
  const audienceSvg = (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 800 500"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect width="100%" height="100%" fill="#222" />
      
      {/* Audience silhouettes in rows */}
      <g opacity="0.6">
        {/* First row (front) */}
        {Array.from({ length: 8 }).map((_, i) => (
          <g key={`row1-${i}`} transform={`translate(${80 + i * 80}, 380)`}>
            <circle cx="20" cy="20" r="15" fill="#444" />
            <rect x="10" y="35" width="20" height="30" rx="5" fill="#444" />
          </g>
        ))}
        
        {/* Second row */}
        {Array.from({ length: 9 }).map((_, i) => (
          <g key={`row2-${i}`} transform={`translate(${50 + i * 80}, 320)`}>
            <circle cx="20" cy="20" r="15" fill="#3A3A3A" />
            <rect x="10" y="35" width="20" height="30" rx="5" fill="#3A3A3A" />
          </g>
        ))}
        
        {/* Third row */}
        {Array.from({ length: 10 }).map((_, i) => (
          <g key={`row3-${i}`} transform={`translate(${25 + i * 80}, 260)`}>
            <circle cx="15" cy="15" r="12" fill="#333" />
            <rect x="8" y="27" width="15" height="25" rx="4" fill="#333" />
          </g>
        ))}
        
        {/* Back rows (more faded) */}
        {Array.from({ length: 11 }).map((_, i) => (
          <g key={`row4-${i}`} opacity="0.7" transform={`translate(${10 + i * 75}, 220)`}>
            <circle cx="10" cy="10" r="8" fill="#2A2A2A" />
            <rect x="5" y="18" width="10" height="15" rx="3" fill="#2A2A2A" />
          </g>
        ))}
      </g>
      
      {/* Stage lights */}
      <circle cx="400" cy="50" r="20" fill="#E83A14" opacity="0.5">
        <animate attributeName="opacity" values="0.3;0.7;0.3" dur="4s" repeatCount="indefinite" />
      </circle>
      <circle cx="200" cy="80" r="15" fill="#E83A14" opacity="0.4">
        <animate attributeName="opacity" values="0.2;0.6;0.2" dur="5s" repeatCount="indefinite" />
      </circle>
      <circle cx="600" cy="80" r="15" fill="#E83A14" opacity="0.4">
        <animate attributeName="opacity" values="0.2;0.6;0.2" dur="5s" repeatCount="indefinite" />
      </circle>
      
      {/* Gradient overlay */}
      <rect
        x="0" y="0" width="100%" height="100%"
        fill="url(#fadeGradient)"
      />
      
      <defs>
        <linearGradient id="fadeGradient" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#121212" stopOpacity="0.8" />
          <stop offset="0.5" stopColor="#121212" stopOpacity="0.3" />
          <stop offset="1" stopColor="#121212" stopOpacity="0" />
        </linearGradient>
      </defs>
    </svg>
  );
  
  // Audience member badges
  const audienceMembers = [
    { name: "Sarah J.", online: true },
    { name: "Raj K.", online: true },
    { name: "Priya M.", online: true },
    { name: "Alex T.", online: true },
    { name: "Mike S.", online: true },
  ];
  
  // Upcoming shows
  const upcomingShows = [
    {
      title: "Bollywood Bloopers",
      comedians: "Cathy & Joe",
      day: "Tomorrow",
      time: "8:00 PM",
    },
    {
      title: "Tech Support Nightmares",
      comedians: "Joe & Priya",
      day: "Saturday",
      time: "9:30 PM",
    },
    {
      title: "Indian Family Gatherings",
      comedians: "Cathy & Amit",
      day: "Next Tuesday",
      time: "7:00 PM",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      {/* Audience View */}
      <div className="bg-darkBg2 rounded-xl overflow-hidden shadow-lg">
        <h3 className="p-4 font-montserrat font-bold border-b border-gray-700 flex items-center">
          <UsersIcon className="text-accentBlue mr-2 h-5 w-5" />
          Live Audience
        </h3>
        <div className="p-4 relative h-48">
          <div className="absolute inset-0 w-full h-full">
            {audienceSvg}
          </div>
          
          <div className="absolute inset-0 bg-gradient-to-t from-darkBg to-transparent"></div>
          
          <div className="absolute bottom-4 left-4 right-4">
            <div className="flex flex-wrap gap-2">
              {audienceMembers.map((member, index) => (
                <div key={index} className="bg-darkBg/80 rounded-full px-3 py-1 text-sm flex items-center">
                  <div className={`w-2 h-2 ${member.online ? 'bg-green-500' : 'bg-gray-500'} rounded-full mr-2`}></div>
                  <span>{member.name}</span>
                </div>
              ))}
              <div className="bg-darkBg/80 rounded-full px-3 py-1 text-sm flex items-center">
                <span>+249 more</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Upcoming Shows */}
      <div className="bg-darkBg2 rounded-xl overflow-hidden shadow-lg">
        <h3 className="p-4 font-montserrat font-bold border-b border-gray-700 flex items-center">
          <CalendarIcon className="text-comedy mr-2 h-5 w-5" />
          Upcoming Comedy Shows
        </h3>
        <div className="divide-y divide-gray-700">
          {upcomingShows.map((show, index) => (
            <div key={index} className="p-4 flex items-center justify-between hover:bg-darkBg3 transition duration-200">
              <div>
                <h4 className="font-medium">{show.title}</h4>
                <p className="text-sm text-grayText">Featuring {show.comedians}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-grayText">{show.day}</p>
                <p className="text-xs bg-darkBg rounded-full px-2 py-0.5 inline-block mt-1">{show.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
