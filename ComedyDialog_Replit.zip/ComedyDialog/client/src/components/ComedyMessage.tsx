import React from 'react';
import { formatDistanceToNow } from 'date-fns';

interface ComedyMessageProps {
  comedian: string;
  content: string;
  timestamp: Date;
  animationDelay: number;
}

export default function ComedyMessage({ comedian, content, timestamp, animationDelay }: ComedyMessageProps) {
  // Determine the side and colors based on the comedian
  const isCathy = comedian.toLowerCase() === 'cathy';
  const bgColor = isCathy ? 'bg-yellow-500/20' : 'bg-blue-500/20';
  const nameColor = isCathy ? 'text-yellow-400' : 'text-blue-400';
  const borderColor = isCathy ? 'border-yellow-500/30' : 'border-blue-500/30';
  const alignment = isCathy ? 'justify-start' : 'justify-end';
  
  return (
    <div 
      className={`flex ${alignment} animate-fadeIn`} 
      style={{ animationDelay: `${animationDelay}s` }}
    >
      <div className={`relative max-w-[80%] ${bgColor} p-4 rounded-xl border ${borderColor}`}>
        <div className="flex items-center mb-2">
          <div className={`w-8 h-8 rounded-full ${isCathy ? 'bg-yellow-500/60' : 'bg-blue-500/60'} flex items-center justify-center text-sm mr-2`}>
            {isCathy ? 'C' : 'J'}
          </div>
          <span className={`font-medium ${nameColor}`}>
            {isCathy ? 'Cathy' : 'Joe'}
          </span>
          <span className="text-gray-400 text-xs ml-auto">
            {formatDistanceToNow(timestamp, { addSuffix: true })}
          </span>
        </div>
        
        <div className="text-white whitespace-pre-wrap">
          {content.split('\n').map((line, i) => (
            <React.Fragment key={i}>
              {line}
              {i < content.split('\n').length - 1 && <br />}
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
}