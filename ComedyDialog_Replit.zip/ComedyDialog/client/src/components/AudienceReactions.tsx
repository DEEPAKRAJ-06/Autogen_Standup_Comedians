import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface AudienceReactionsProps {
  isActive: boolean;
}

interface Reaction {
  id: string;
  text: string;
  icon: JSX.Element;
}

const reactions: Reaction[] = [
  { 
    id: "laugh", 
    text: "Hilarious!", 
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-yellow-400 mr-1" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM7 9a1 1 0 100-2 1 1 0 000 2zm7-1a1 1 0 11-2 0 1 1 0 012 0zm-7.536 5.879a1 1 0 001.415 0 3 3 0 014.242 0 1 1 0 001.415-1.415 5 5 0 00-7.072 0 1 1 0 000 1.415z" clipRule="evenodd" />
      </svg>
    )
  },
  { 
    id: "good", 
    text: "Good one!", 
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-green-400 mr-1" viewBox="0 0 20 20" fill="currentColor">
        <path d="M2 10.5a1.5 1.5 0 113 0v6a1.5 1.5 0 01-3 0v-6zM6 10.333v5.43a2 2 0 001.106 1.79l.05.025A4 4 0 008.943 18h5.416a2 2 0 001.962-1.608l1.2-6A2 2 0 0015.56 8H12V4a2 2 0 00-2-2 1 1 0 00-1 1v.667a4 4 0 01-.8 2.4L6.8 7.933a4 4 0 00-.8 2.4z" />
      </svg>
    )
  },
  { 
    id: "fire", 
    text: "On fire!", 
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-comedy-red mr-1" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M12.395 2.553a1 1 0 00-1.45-.385c-.345.23-.614.558-.822.88-.214.33-.403.713-.57 1.116-.334.804-.614 1.768-.84 2.734a31.365 31.365 0 00-.613 3.58 2.64 2.64 0 01-.945-1.067c-.328-.68-.398-1.534-.398-2.654A1 1 0 005.05 6.05 6.981 6.981 0 003 11a7 7 0 1011.95-4.95c-.592-.591-.98-.985-1.348-1.467-.363-.476-.724-1.063-1.207-2.03zM12.12 15.12A3 3 0 017 13s.879.5 2.5.5c0-1 .5-4 1.25-4.5.5 1 .786 1.293 1.371 1.879A2.99 2.99 0 0113 13a2.99 2.99 0 01-.879 2.121z" clipRule="evenodd" />
      </svg>
    )
  },
  { 
    id: "clap", 
    text: "Bravo!", 
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-blue-400 mr-1" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M5 2a1 1 0 011 1v1h1a1 1 0 010 2H6v1a1 1 0 01-2 0V6H3a1 1 0 010-2h1V3a1 1 0 011-1zm0 10a1 1 0 011 1v1h1a1 1 0 110 2H6v1a1 1 0 11-2 0v-1H3a1 1 0 110-2h1v-1a1 1 0 011-1zm7-10a1 1 0 01.707.293l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 8l-3.293-3.293A1 1 0 0112 4z" clipRule="evenodd" />
      </svg>
    )
  }
];

const AudienceReactions: React.FC<AudienceReactionsProps> = ({ isActive }) => {
  const [visibleReactions, setVisibleReactions] = useState<string[]>([]);

  useEffect(() => {
    if (!isActive) {
      setVisibleReactions([]);
      return;
    }

    // Function to show a random reaction
    const showRandomReaction = () => {
      // Randomly select a reaction
      const randomReaction = reactions[Math.floor(Math.random() * reactions.length)];
      
      // Add it to visible reactions
      setVisibleReactions(prev => [...prev, randomReaction.id]);
      
      // Remove it after a delay
      setTimeout(() => {
        setVisibleReactions(prev => prev.filter(id => id !== randomReaction.id));
      }, 2000);
    };

    // Start showing reactions at random intervals
    const intervalTime = Math.random() * (5000 - 2000) + 2000; // Between 2-5 seconds
    const intervalId = setInterval(showRandomReaction, intervalTime);
    
    // Clear interval on cleanup
    return () => clearInterval(intervalId);
  }, [isActive]);

  return (
    <div className="reaction-overlay fixed bottom-4 right-4 flex flex-col items-end space-y-2 z-50 pointer-events-none">
      <AnimatePresence>
        {reactions.map((reaction) => (
          visibleReactions.includes(reaction.id) && (
            <motion.div
              key={reaction.id}
              className="bg-black bg-opacity-50 rounded-full px-3 py-1 text-sm text-gray-300 flex items-center"
              initial={{ opacity: 0, scale: 0.8, x: 20 }}
              animate={{ opacity: 1, scale: 1, x: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              {reaction.icon}
              {reaction.text}
            </motion.div>
          )
        ))}
      </AnimatePresence>
    </div>
  );
};

export default AudienceReactions;
