import React from "react";

interface ComedianProfileProps {
  name: string; // "cathy" or "joe"
  displayName: string;
  avatarUrl: string;
  title: string;
  description: string;
}

export default function ComedianProfile({
  name,
  displayName,
  avatarUrl,
  title,
  description
}: ComedianProfileProps) {
  // SVG avatars for comedians to avoid using bitmap images
  const avatarSvg = (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 80 80"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect width="80" height="80" fill="#333" />
      {name.toLowerCase() === "cathy" ? (
        // Cathy avatar
        <>
          <circle cx="40" cy="30" r="15" fill="#ffd700" />
          <circle cx="40" cy="70" r="30" fill="#ffd700" />
          <path d="M25,35 Q40,50 55,35" stroke="#333" strokeWidth="3" fill="none" />
        </>
      ) : (
        // Joe avatar
        <>
          <circle cx="40" cy="30" r="15" fill="#3498db" />
          <circle cx="40" cy="70" r="30" fill="#3498db" />
          <path d="M30,32 L35,37 M45,37 L50,32" stroke="#333" strokeWidth="2" fill="none" />
          <path d="M30,38 Q40,45 50,38" stroke="#333" strokeWidth="2" fill="none" />
        </>
      )}
    </svg>
  );
  
  return (
    <div 
      id={`comedian-${name.toLowerCase()}`}
      className="bg-black/50 rounded-xl p-6 shadow-lg mb-4 transform transition-all duration-300 hover:shadow-xl"
    >
      <div className="flex items-center mb-4">
        <div className="relative">
          <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-white/20">
            {avatarSvg}
          </div>
          <div className="absolute -bottom-1 -right-1 bg-green-500 w-4 h-4 rounded-full border-2 border-black"></div>
        </div>
        <div className="ml-4">
          <h3 className="font-bold text-xl text-white">{displayName}</h3>
          <p className="text-gray-300 text-sm">Indian stand-up comedian</p>
        </div>
      </div>
      
      <div className="space-y-3">
        <div>
          <h4 className="text-yellow-400 font-medium mb-1">{title}</h4>
          <p className="text-gray-300 text-sm">{description}</p>
        </div>
      </div>
    </div>
  );
}
