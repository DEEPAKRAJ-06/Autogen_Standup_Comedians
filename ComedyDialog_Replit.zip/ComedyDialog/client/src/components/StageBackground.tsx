import React from "react";

export function StageBackground() {
  return (
    <div className="relative mb-8 rounded-xl overflow-hidden h-64 md:h-80 bg-darkBg3 shadow-2xl">
      {/* Stage Background */}
      <div className="absolute inset-0 w-full h-full bg-darkBg3">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="100%"
          height="100%"
          viewBox="0 0 1200 500"
          preserveAspectRatio="xMidYMid slice"
        >
          {/* Dark background with patterns */}
          <rect width="100%" height="100%" fill="#1E1E1E" />
          
          {/* Stage patterns */}
          <g opacity="0.2">
            <circle cx="200" cy="250" r="80" fill="#333" />
            <circle cx="600" cy="350" r="120" fill="#333" />
            <circle cx="1000" cy="200" r="100" fill="#333" />
            <path d="M0,500 L1200,500 L1200,350 C900,450 300,300 0,400 Z" fill="#111" />
          </g>
        </svg>
      </div>
      
      {/* Spotlight Effect */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-48 h-48 md:w-64 md:h-64 rounded-full bg-gradient-to-b from-spotlight/30 to-transparent animate-spotlight"></div>
      </div>
      
      {/* Stage Microphone */}
      <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-8 h-64 flex flex-col items-center">
        <div className="w-8 h-24 bg-darkBg2 rounded-t-lg"></div>
        <div className="w-4 h-16 bg-gray-700"></div>
        <div className="w-8 h-8 rounded-full bg-darkBg3 border-2 border-gray-700"></div>
      </div>
      
      {/* Current Status */}
      <div className="absolute top-4 left-4 bg-darkBg2/80 px-3 py-1 rounded-full text-sm flex items-center">
        <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse mr-2"></span>
        <span id="status-text">Comedy in progress</span>
      </div>
    </div>
  );
}
