import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PlayIcon, ResetIcon, SpinnerIcon } from "@/assets/icons";

const TOPICS = [
  { value: "arranged-marriage", label: "Arranged Marriage" },
  { value: "indian-politics", label: "Indian Politics" },
  { value: "bollywood", label: "Bollywood Movies" },
  { value: "tech-support", label: "Tech Support" },
  { value: "family-gatherings", label: "Family Gatherings" },
  { value: "indian-food", label: "Indian Food" },
  { value: "custom", label: "Custom Topic..." },
];

const TURNS = [
  { value: "2", label: "2 turns" },
  { value: "4", label: "4 turns" },
  { value: "6", label: "6 turns" },
  { value: "8", label: "8 turns" },
];

const STYLES = [
  { value: "observational", label: "Observational" },
  { value: "sarcastic", label: "Sarcastic" },
  { value: "self-deprecating", label: "Self-deprecating" },
  { value: "absurdist", label: "Absurdist" },
];

interface ComedyControlsProps {
  onStartComedy: (settings: {
    topic: string;
    customTopic?: string;
    turns: number;
    style: string;
  }) => void;
  onResetComedy: () => void;
  isLoading: boolean;
}

export function ComedyControls({
  onStartComedy,
  onResetComedy,
  isLoading
}: ComedyControlsProps) {
  const [topic, setTopic] = useState("arranged-marriage");
  const [customTopic, setCustomTopic] = useState("");
  const [turns, setTurns] = useState("4");
  const [style, setStyle] = useState("observational");

  const handleStart = () => {
    onStartComedy({
      topic,
      customTopic: topic === "custom" ? customTopic : undefined,
      turns: parseInt(turns),
      style,
    });
  };

  return (
    <div className="bg-darkBg2 rounded-xl p-6 shadow-lg flex flex-col">
      <h3 className="font-montserrat font-bold text-xl mb-4 text-center">Comedy Controls</h3>
      
      {/* Topic Selection */}
      <div className="mb-6">
        <Label className="block text-grayText mb-2 text-sm">Comedy Topic</Label>
        <Select 
          value={topic} 
          onValueChange={setTopic}
        >
          <SelectTrigger className="w-full bg-darkBg3 border border-gray-700 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-spotlight text-lightText">
            <SelectValue placeholder="Select a comedy topic" />
          </SelectTrigger>
          <SelectContent className="bg-darkBg3 text-lightText border-gray-700">
            {TOPICS.map((t) => (
              <SelectItem key={t.value} value={t.value}>
                {t.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        {/* Custom Topic Input */}
        {topic === "custom" && (
          <div className="mt-3">
            <Input
              id="custom-topic"
              value={customTopic}
              onChange={(e) => setCustomTopic(e.target.value)}
              placeholder="Enter your comedy topic"
              className="w-full bg-darkBg3 border border-gray-700 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-spotlight text-lightText"
            />
          </div>
        )}
      </div>
      
      {/* Joke Settings */}
      <div className="mb-6 grid grid-cols-2 gap-3">
        <div>
          <Label className="block text-grayText mb-1 text-sm">Turns</Label>
          <Select 
            value={turns} 
            onValueChange={setTurns}
          >
            <SelectTrigger className="w-full bg-darkBg3 border border-gray-700 rounded-lg px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-spotlight text-lightText">
              <SelectValue placeholder="Select turns" />
            </SelectTrigger>
            <SelectContent className="bg-darkBg3 text-lightText border-gray-700">
              {TURNS.map((t) => (
                <SelectItem key={t.value} value={t.value}>
                  {t.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="block text-grayText mb-1 text-sm">Style</Label>
          <Select 
            value={style} 
            onValueChange={setStyle}
          >
            <SelectTrigger className="w-full bg-darkBg3 border border-gray-700 rounded-lg px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-spotlight text-lightText">
              <SelectValue placeholder="Select style" />
            </SelectTrigger>
            <SelectContent className="bg-darkBg3 text-lightText border-gray-700">
              {STYLES.map((s) => (
                <SelectItem key={s.value} value={s.value}>
                  {s.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {/* Control Buttons */}
      <div className="flex gap-4 mt-auto">
        <Button
          onClick={handleStart}
          disabled={isLoading || (topic === "custom" && !customTopic)}
          className="flex-1 bg-spotlight hover:bg-red-600 text-white font-bold py-3 px-4 rounded-lg shadow-md transition duration-300 flex items-center justify-center"
        >
          {isLoading ? (
            <>
              <SpinnerIcon className="mr-2 h-4 w-4" />
              Loading...
            </>
          ) : (
            <>
              <PlayIcon className="mr-2 h-4 w-4" />
              Start Show
            </>
          )}
        </Button>
        <Button
          onClick={onResetComedy}
          disabled={isLoading}
          className="bg-darkBg3 hover:bg-gray-700 text-white py-3 px-4 rounded-lg shadow-md transition duration-300"
        >
          <ResetIcon className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
