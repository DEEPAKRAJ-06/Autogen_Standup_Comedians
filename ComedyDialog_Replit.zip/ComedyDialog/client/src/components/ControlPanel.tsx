import React, { useState } from 'react';
import { comedyTopics } from '@/lib/comedy-topics';

interface ControlPanelProps {
  onStart: (topic: string, customTopic?: string) => void;
  onReset: () => void;
  isLoading: boolean;
}

export default function ControlPanel({ onStart, onReset, isLoading }: ControlPanelProps) {
  const [selectedTopic, setSelectedTopic] = useState<string>(comedyTopics[0]?.value || 'travel');
  const [customTopic, setCustomTopic] = useState<string>('');
  const [showCustom, setShowCustom] = useState<boolean>(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (showCustom && customTopic.trim()) {
      onStart(selectedTopic, customTopic.trim());
    } else {
      onStart(selectedTopic);
    }
  };

  return (
    <div className="mt-auto bg-black/30 rounded-lg p-4 space-y-4">
      <h3 className="font-medium text-lg text-yellow-400 mb-3">Start Comedy Show</h3>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="topic" className="block text-sm text-gray-300 mb-1">
            Select a topic:
          </label>
          <select
            id="topic"
            value={selectedTopic}
            onChange={(e) => setSelectedTopic(e.target.value)}
            className="w-full bg-black/50 text-white border border-gray-700 rounded-md p-2"
            disabled={isLoading}
          >
            {comedyTopics.map((topic) => (
              <option key={topic.value} value={topic.value}>
                {topic.label}
              </option>
            ))}
            <option value="custom">Custom Topic...</option>
          </select>
        </div>
        
        {selectedTopic === 'custom' && (
          <div>
            <label htmlFor="customTopic" className="block text-sm text-gray-300 mb-1">
              Enter custom topic:
            </label>
            <input
              id="customTopic"
              type="text"
              value={customTopic}
              onChange={(e) => setCustomTopic(e.target.value)}
              className="w-full bg-black/50 text-white border border-gray-700 rounded-md p-2"
              placeholder="Enter any topic..."
              disabled={isLoading}
              autoFocus
            />
          </div>
        )}
        
        <div className="flex space-x-2 pt-2">
          <button
            type="submit"
            className="flex-1 bg-yellow-500 hover:bg-yellow-600 text-black font-medium py-2 px-4 rounded-md transition-colors flex items-center justify-center"
            disabled={isLoading || (selectedTopic === 'custom' && !customTopic.trim())}
          >
            {isLoading ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Generating...
              </>
            ) : (
              'Start Comedy'
            )}
          </button>
          
          <button
            type="button"
            onClick={onReset}
            className="bg-gray-700 hover:bg-gray-600 text-white py-2 px-4 rounded-md transition-colors"
            disabled={isLoading}
          >
            Reset
          </button>
        </div>
      </form>
    </div>
  );
}