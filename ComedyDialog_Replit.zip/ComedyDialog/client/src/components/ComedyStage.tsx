import React from 'react';
import { useIsMobile } from '@/hooks/use-mobile';
import ComedyMessage from './ComedyMessage';

interface ComedyMessage {
  id: number | string;
  comedian: string;
  content: string;
  timestamp: Date;
}

export interface ComedyConversation {
  id: number;
  topic: string;
  messages: ComedyMessage[];
  createdAt: Date;
  isComplete: boolean;
}

interface ComedyStageProps {
  conversation: ComedyConversation | null;
  isLoading: boolean;
  hasError: boolean;
  currentTopic: string;
  onRetry: () => void;
}

export default function ComedyStage({ conversation, isLoading, hasError, currentTopic, onRetry }: ComedyStageProps) {
  const isMobile = useIsMobile();
  
  // Placeholder for when no conversation is selected
  if (!conversation && !isLoading && !hasError) {
    return (
      <main className="flex-1 bg-gradient-to-b from-black to-gray-900 p-4 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto">
          <h2 className="text-2xl font-bold text-yellow-400 mb-4">Welcome to the AI Comedy Club!</h2>
          <p className="text-gray-300 mb-6">Select a topic from the sidebar to start a comedy conversation between our AI comedians.</p>
          <div className="flex items-center justify-center gap-6">
            <div className="text-center">
              <div className="w-20 h-20 mx-auto rounded-full bg-yellow-500 opacity-60 flex items-center justify-center text-2xl">
                😄
              </div>
              <p className="mt-2 text-gray-300">Cathy</p>
            </div>
            <div className="text-center">
              <div className="w-20 h-20 mx-auto rounded-full bg-blue-500 opacity-60 flex items-center justify-center text-2xl">
                😎
              </div>
              <p className="mt-2 text-gray-300">Joe</p>
            </div>
          </div>
        </div>
      </main>
    );
  }
  
  // Loading state
  if (isLoading) {
    return (
      <main className="flex-1 bg-gradient-to-b from-black to-gray-900 p-4 flex flex-col">
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-yellow-400 mb-4"></div>
            <p className="text-gray-300">Preparing comedy conversation about <span className="text-yellow-400 font-medium">{currentTopic}</span>...</p>
          </div>
        </div>
      </main>
    );
  }
  
  // Error state
  if (hasError) {
    return (
      <main className="flex-1 bg-gradient-to-b from-black to-gray-900 p-4 flex flex-col">
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center bg-black/30 rounded-xl p-6 max-w-md">
            <div className="text-red-500 text-5xl mb-4">😕</div>
            <h2 className="text-xl font-bold text-red-400 mb-3">Comedy Show Error</h2>
            <p className="text-gray-300 mb-4">Sorry, we couldn't generate the comedy conversation. Please try again.</p>
            <button 
              onClick={onRetry}
              className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg transition-colors"
            >
              Try Again
            </button>
          </div>
        </div>
      </main>
    );
  }
  
  // Regular conversation display
  return (
    <main className="flex-1 bg-gradient-to-b from-black to-gray-900 p-4 lg:p-6 flex flex-col overflow-hidden">
      {/* Topic header */}
      <div className="bg-black/40 rounded-lg p-3 mb-4 sticky top-0 z-10">
        <h2 className="text-lg font-medium text-center">
          <span className="text-gray-400">Topic: </span>
          <span className="text-yellow-400">{conversation?.topic || currentTopic}</span>
        </h2>
      </div>
      
      {/* Messages */}
      <div className="flex-1 overflow-y-auto space-y-4 pb-4">
        {conversation?.messages.length === 0 ? (
          <p className="text-center text-gray-400 italic py-12">The conversation will appear here...</p>
        ) : (
          conversation?.messages.map((message, index) => (
            <ComedyMessage
              key={message.id}
              comedian={message.comedian}
              content={message.content}
              timestamp={message.timestamp}
              animationDelay={index * 0.2}
            />
          ))
        )}
        
        {/* Show "typing" indicator if conversation is in progress */}
        {conversation && !conversation.isComplete && conversation.messages.length > 0 && (
          <div className="flex items-center p-4 bg-black/20 rounded-lg animate-pulse">
            <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center text-sm mr-3">
              {conversation.messages.length % 2 === 0 ? "C" : "J"}
            </div>
            <div className="flex space-x-1">
              <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: "0ms" }}></div>
              <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: "300ms" }}></div>
              <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: "600ms" }}></div>
            </div>
          </div>
        )}
      </div>
      
      {/* Conversation finished indicator */}
      {conversation?.isComplete && (
        <div className="text-center p-3 bg-black/30 rounded-lg text-gray-400 mt-4">
          Comedy show completed! You can start a new one.
        </div>
      )}
    </main>
  );
}