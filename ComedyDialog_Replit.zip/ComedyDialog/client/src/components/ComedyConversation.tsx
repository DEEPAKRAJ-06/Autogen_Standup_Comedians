import React, { useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { LaughIcon, FireIcon, HeartIcon, ShareIcon, BookmarkIcon, LiveDotIcon, UsersIcon } from "@/assets/icons";

interface Message {
  speaker: "cathy" | "joe";
  message: string;
}

interface ComedyConversationProps {
  messages: Message[];
  isLoading: boolean;
  audienceCount: number;
}

export function ComedyConversation({
  messages,
  isLoading,
  audienceCount,
}: ComedyConversationProps) {
  const chatEndRef = useRef<HTMLDivElement>(null);
  const [reactions, setReactions] = React.useState({
    laugh: 42,
    fire: 28,
    heart: 15,
  });

  useEffect(() => {
    // Scroll to bottom when messages change
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const handleReaction = (type: "laugh" | "fire" | "heart") => {
    setReactions((prev) => ({
      ...prev,
      [type]: prev[type] + 1,
    }));
  };

  // Create avatar SVGs for comedians
  const getAvatar = (speaker: "cathy" | "joe") => (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 40 40"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect width="40" height="40" fill="#333" />
      {speaker === "cathy" ? (
        <>
          <circle cx="20" cy="15" r="7" fill="#ffd700" />
          <circle cx="20" cy="35" r="15" fill="#ffd700" />
          <path d="M12,17 Q20,25 28,17" stroke="#333" strokeWidth="2" fill="none" />
        </>
      ) : (
        <>
          <circle cx="20" cy="15" r="7" fill="#3498db" />
          <circle cx="20" cy="35" r="15" fill="#3498db" />
          <path d="M15,16 L17,18 M23,18 L25,16" stroke="#333" strokeWidth="1" fill="none" />
          <path d="M15,19 Q20,22 25,19" stroke="#333" strokeWidth="1" fill="none" />
        </>
      )}
    </svg>
  );

  // Format message content with proper paragraphs
  const formatMessage = (message: string) => {
    return message.split("\n\n").map((paragraph, i) => (
      <p key={i} className={i > 0 ? "mt-3" : ""}>
        {paragraph}
      </p>
    ));
  };

  return (
    <div className="bg-darkBg2 rounded-xl overflow-hidden shadow-xl mb-8">
      {/* Comedy Club Background */}
      <div className="relative p-4 bg-darkBg3 flex items-center justify-between border-b border-gray-700">
        <div className="flex items-center">
          {/* Club audience icon */}
          <div className="w-8 h-8 rounded-full overflow-hidden bg-gray-600 mr-2 relative">
            <svg viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg">
              <rect width="50" height="50" fill="#555" />
              <circle cx="15" cy="20" r="5" fill="#777" />
              <circle cx="30" cy="18" r="6" fill="#888" />
              <circle cx="25" cy="30" r="4" fill="#666" />
              <circle cx="40" cy="25" r="5" fill="#777" />
              <circle cx="10" cy="35" r="6" fill="#888" />
            </svg>
          </div>
          <h3 className="font-montserrat font-bold">Live Comedy Session</h3>
        </div>
        <div className="flex items-center space-x-2">
          <div className="flex items-center bg-darkBg px-2 py-1 rounded-full text-xs">
            <LiveDotIcon className="text-red-500 h-3 w-3 mr-1" />
            <span>LIVE</span>
          </div>
          <div className="bg-darkBg px-2 py-1 rounded-full text-xs flex items-center">
            <UsersIcon className="h-3 w-3 mr-1" />
            <span>{audienceCount}</span>
          </div>
        </div>
      </div>
      
      {/* Comedy Conversation */}
      <div id="comedy-conversation" className="h-96 overflow-y-auto p-6 space-y-6">
        {/* Loading State */}
        {isLoading && messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-grayText animate-pulse-slow">
            <svg
              className="text-4xl mb-4 text-spotlight"
              xmlns="http://www.w3.org/2000/svg"
              width="48"
              height="48"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z" />
              <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
              <line x1="12" x2="12" y1="19" y2="22" />
            </svg>
            <p className="text-center">Preparing the stage...</p>
            <p className="text-center text-sm mt-2">The comedians are warming up</p>
          </div>
        )}
        
        {/* Comedy Conversation */}
        <div id="chat-container" className={messages.length === 0 ? "hidden" : ""}>
          {messages.map((message, index) => (
            <div 
              key={index} 
              className={`chat-message ${message.speaker}-message ${index > 0 ? 'mt-6' : ''} animate-fadeIn`}
            >
              <div className={`flex items-start mb-2 ${message.speaker === 'cathy' ? 'justify-end' : ''}`}>
                {message.speaker !== 'cathy' && (
                  <div className="w-8 h-8 rounded-full overflow-hidden mr-2">
                    {getAvatar("joe")}
                  </div>
                )}
                <div className={`font-bold ${message.speaker === 'cathy' ? 'text-comedy mr-2' : 'text-accentBlue'}`}>
                  {message.speaker === 'cathy' ? 'Cathy' : 'Joe'}
                </div>
                {message.speaker === 'cathy' && (
                  <div className="w-8 h-8 rounded-full overflow-hidden">
                    {getAvatar("cathy")}
                  </div>
                )}
              </div>
              <div 
                className={`bg-darkBg3 rounded-lg ${
                  message.speaker === 'cathy' ? 'rounded-tr-none ml-auto' : 'rounded-tl-none'
                } p-4 shadow font-comic`}
              >
                {formatMessage(message.message)}
              </div>
            </div>
          ))}
          <div ref={chatEndRef} />
        </div>
      </div>
      
      {/* Audience Reaction Bar */}
      <div className="p-4 bg-darkBg3 border-t border-gray-700 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <Button
            variant="outline"
            size="sm"
            className="bg-darkBg hover:bg-gray-800 px-3 py-1 rounded-full text-sm flex items-center"
            onClick={() => handleReaction("laugh")}
          >
            <LaughIcon className="text-yellow-400 mr-1 h-4 w-4" />
            <span>{reactions.laugh}</span>
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="bg-darkBg hover:bg-gray-800 px-3 py-1 rounded-full text-sm flex items-center"
            onClick={() => handleReaction("fire")}
          >
            <FireIcon className="text-red-500 mr-1 h-4 w-4" />
            <span>{reactions.fire}</span>
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="bg-darkBg hover:bg-gray-800 px-3 py-1 rounded-full text-sm flex items-center"
            onClick={() => handleReaction("heart")}
          >
            <HeartIcon className="text-pink-500 mr-1 h-4 w-4" />
            <span>{reactions.heart}</span>
          </Button>
        </div>
        
        <div className="w-full sm:w-auto flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="bg-darkBg hover:bg-gray-800 px-3 py-1 rounded-full text-sm flex items-center"
          >
            <ShareIcon className="text-accentBlue mr-1 h-4 w-4" />
            Share
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="bg-darkBg hover:bg-gray-800 px-3 py-1 rounded-full text-sm flex items-center"
          >
            <BookmarkIcon className="text-accentPurple mr-1 h-4 w-4" />
            Save
          </Button>
        </div>
      </div>
    </div>
  );
}
