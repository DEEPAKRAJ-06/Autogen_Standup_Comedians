import React from "react";
import { ComedyClub } from "@/components/ComedyClub";

export default function Home() {
  return <ComedyClub />;
}
