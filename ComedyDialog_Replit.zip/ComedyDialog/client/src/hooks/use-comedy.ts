import { useState, useEffect, useCallback } from "react";
import { ComedyConversation, ComedyMessage, WebSocketMessage } from "@shared/schema";
import { useWebSocket } from "./use-websocket";
import { useToast } from "./use-toast";
import { comedyTopics } from "@/lib/comedy-topics";

export function useComedy() {
  const [currentTopic, setCurrentTopic] = useState<string>("Arranged Marriages");
  const [conversation, setConversation] = useState<ComedyConversation | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);
  const { toast } = useToast();
  
  // Initialize WebSocket connection
  const { 
    sendMessage, 
    lastMessage, 
    readyState, 
    connectionStatus, 
    error: wsError 
  } = useWebSocket();
  
  // Start a conversation with the specified topic
  const startConversation = useCallback((topicKey: string, customTopic?: string) => {
    console.log(`Starting conversation with topic: ${topicKey}${customTopic ? `, custom topic: ${customTopic}` : ''}`);
    setIsLoading(true);
    setError(null);
    
    // Find the topic label for display
    const topicLabel = customTopic || 
      comedyTopics.find(t => t.value === topicKey)?.label || 
      "Comedy";
    
    setCurrentTopic(topicLabel);
    
    // Reset current conversation
    setConversation({
      id: Date.now(),
      topic: topicLabel,
      messages: [],
      createdAt: new Date(),
      isComplete: false
    });
    
    // Start the conversation via WebSocket
    try {
      sendMessage({
        type: 'start',
        payload: {
          topic: topicKey,
          maxTurns: 5,
          customTopic
        }
      });
      
      console.log("Start message sent successfully");
    } catch (err) {
      console.error("Error sending start message:", err);
      setError(err instanceof Error ? err : new Error(String(err)));
      setIsLoading(false);
      toast({
        title: "Connection Error",
        description: "Failed to start the comedy show. Please try again.",
        variant: "destructive"
      });
    }
  }, [sendMessage, toast]);
  
  // Reset the conversation
  const resetConversation = useCallback(() => {
    console.log("Resetting conversation");
    setConversation(null);
    setIsLoading(false);
    setError(null);
  }, []);
  
  // Process incoming WebSocket messages
  useEffect(() => {
    if (lastMessage) {
      try {
        console.log("Received WebSocket message:", lastMessage.data);
        const message = JSON.parse(lastMessage.data) as WebSocketMessage;
        console.log("Parsed message type:", message.type);
        
        switch (message.type) {
          case 'start':
            // Conversation started or updated status
            console.log("Start message received:", message.payload);
            if (message.payload.status === 'ready' && message.payload.conversationId) {
              // Conversation fully initialized
              setConversation(prev => {
                if (!prev) return null;
                return {
                  ...prev,
                  id: message.payload.conversationId,
                  topic: message.payload.topic || prev.topic
                };
              });
            }
            // Keep loading until we get messages
            break;
            
          case 'message':
            // New message received
            console.log("Message received:", message.payload);
            
            // Skip system messages or handle them differently
            if (message.payload.comedian === 'system') {
              // Optionally show system messages
              console.log("System message:", message.payload.content);
              return;
            }
            
            setConversation(prev => {
              if (!prev) return null;
              
              const newMessage: ComedyMessage = {
                id: Date.now(),
                comedian: message.payload.comedian,
                content: message.payload.content,
                timestamp: new Date(message.payload.timestamp)
              };
              
              return {
                ...prev,
                messages: [...prev.messages, newMessage]
              };
            });
            break;
            
          case 'complete':
            // Conversation completed
            console.log("Conversation complete");
            setIsLoading(false);
            setConversation(prev => {
              if (!prev) return null;
              return { ...prev, isComplete: true };
            });
            
            toast({
              title: "Show Complete",
              description: "The comedy show has ended. Enjoy the laughs!",
              variant: "default"
            });
            break;
            
          case 'error':
            // Error occurred
            console.error("Error message received:", message.payload);
            setError(new Error(message.payload.error || "An error occurred"));
            setIsLoading(false);
            toast({
              title: "Comedy Show Error",
              description: message.payload.error || "Something went wrong with the comedy show.",
              variant: "destructive"
            });
            break;
            
          default:
            console.warn("Unknown message type:", message.type);
            break;
        }
      } catch (err) {
        console.error("Failed to parse WebSocket message:", err, "Raw message:", lastMessage.data);
      }
    }
  }, [lastMessage, toast]);
  
  // Handle WebSocket connection status changes
  useEffect(() => {
    console.log("WebSocket connection status changed:", connectionStatus);
    
    if (connectionStatus === 'Connected') {
      // Connection established
      console.log("WebSocket connected successfully");
    } else if (connectionStatus === 'Connecting') {
      // Connecting to WebSocket
      console.log("Connecting to WebSocket...");
    } else if (connectionStatus === 'Closed') {
      // Connection closed
      console.log("WebSocket connection closed");
      
      if (isLoading) {
        setIsLoading(false);
        setError(new Error("Connection closed"));
        toast({
          title: "Connection Lost",
          description: "The connection to the comedy server was lost. Please try again.",
          variant: "destructive"
        });
      }
    }
  }, [connectionStatus, isLoading, toast]);
  
  // Handle WebSocket errors
  useEffect(() => {
    if (wsError) {
      console.error("WebSocket error:", wsError);
      setError(wsError);
      setIsLoading(false);
      toast({
        title: "Connection Error",
        description: wsError.message || "Failed to connect to the comedy server.",
        variant: "destructive"
      });
    }
  }, [wsError, toast]);
  
  // Mark loading as complete once we get enough messages
  useEffect(() => {
    const messagesCount = conversation?.messages?.length || 0;
    if (isLoading && messagesCount >= 3) {
      console.log("Enough messages received, marking as not loading");
      setIsLoading(false);
    }
  }, [isLoading, conversation]);
  
  return {
    conversation,
    isLoading,
    error,
    startConversation,
    resetConversation,
    currentTopic
  };
}
