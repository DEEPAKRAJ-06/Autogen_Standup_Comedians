import { useState, useEffect, useRef, useCallback } from "react";

type ConnectionStatus = "Connecting" | "Connected" | "Closed";

// Construct WebSocket URL with a specific path to avoid conflicts with Vite's WebSocket
function getWebSocketUrl() {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const host = window.location.host;
  return `${protocol}//${host}/ws/comedy`;
}

// Custom WebSocket hook with improved error handling
export function useWebSocket(url?: string) {
  const [lastMessage, setLastMessage] = useState<MessageEvent | null>(null);
  const [readyState, setReadyState] = useState<number>(WebSocket.CONNECTING);
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>("Connecting");
  const [error, setError] = useState<Error | null>(null);
  const socketRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<number | null>(null);
  const reconnectCountRef = useRef<number>(0);
  
  // Use the provided URL or calculate the default one
  const wsUrl = url || getWebSocketUrl();

  // Initialize WebSocket connection
  useEffect(() => {
    let isActive = true; // Flag to prevent state updates after unmount

    // Function to create and set up the WebSocket connection
    const setupWebSocket = () => {
      try {
        // Don't reconnect too many times
        if (reconnectCountRef.current > 5) {
          console.log("Too many reconnection attempts, giving up");
          if (isActive) {
            setError(new Error("Failed to connect after multiple attempts"));
            setReadyState(WebSocket.CLOSED);
            setConnectionStatus("Closed");
          }
          return;
        }
        
        console.log("Connecting to WebSocket at:", wsUrl);
        const socket = new WebSocket(wsUrl);
        
        if (isActive) {
          socketRef.current = socket;
          setReadyState(WebSocket.CONNECTING);
          setConnectionStatus("Connecting");
        }

        // Connection opened
        socket.onopen = () => {
          if (isActive) {
            console.log("WebSocket connection established");
            reconnectCountRef.current = 0; // Reset reconnect counter on successful connection
            setReadyState(WebSocket.OPEN);
            setConnectionStatus("Connected");
            setError(null);
          }
        };

        // Listen for messages
        socket.onmessage = (event) => {
          if (isActive) {
            try {
              const message = typeof event.data === 'string' ? event.data : 'Binary data';
              const preview = message.length > 100 ? message.slice(0, 100) + "..." : message;
              console.log("Received WebSocket message:", preview);
              setLastMessage(event);
            } catch (err) {
              console.error("Error processing received message:", err);
            }
          }
        };

        // Connection closed
        socket.onclose = (event) => {
          if (isActive) {
            console.log("WebSocket connection closed:", event.code, event.reason);
            setReadyState(WebSocket.CLOSED);
            setConnectionStatus("Closed");
            
            // Try to reconnect after a delay if it wasn't intentionally closed
            if (event.code !== 1000) {
              reconnectCountRef.current += 1;
              const delay = Math.min(1000 * Math.pow(1.5, reconnectCountRef.current), 30000); // Exponential backoff with 30s max
              console.log(`Attempting to reconnect in ${delay/1000}s (attempt ${reconnectCountRef.current})`);
              reconnectTimeoutRef.current = window.setTimeout(setupWebSocket, delay);
            }
          }
        };

        // Connection error
        socket.onerror = (event) => {
          if (isActive) {
            console.error("WebSocket connection error", event);
            setError(new Error("WebSocket connection error"));
            // Don't set status to closed here as the onclose handler will be called
          }
        };
      } catch (err) {
        if (isActive) {
          console.error("Error creating WebSocket:", err);
          setError(err instanceof Error ? err : new Error(String(err)));
          setReadyState(WebSocket.CLOSED);
          setConnectionStatus("Closed");
          
          // Try to reconnect after a delay
          reconnectCountRef.current += 1;
          const delay = Math.min(1000 * Math.pow(1.5, reconnectCountRef.current), 30000);
          console.log(`Attempting to reconnect in ${delay/1000}s (attempt ${reconnectCountRef.current})`);
          reconnectTimeoutRef.current = window.setTimeout(setupWebSocket, delay);
        }
      }
    };

    // Initial setup
    setupWebSocket();

    // Cleanup on unmount
    return () => {
      isActive = false;
      
      if (reconnectTimeoutRef.current !== null) {
        window.clearTimeout(reconnectTimeoutRef.current);
      }
      
      if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
        try {
          socketRef.current.close(1000, "Component unmounted");
        } catch (err) {
          console.error("Error closing WebSocket:", err);
        }
      }
    };
  }, [wsUrl]);

  // Send message through WebSocket
  const sendMessage = useCallback((data: any) => {
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      try {
        const jsonString = JSON.stringify(data);
        const preview = jsonString.length > 100 ? jsonString.slice(0, 100) + "..." : jsonString;
        console.log("Sending WebSocket message:", preview);
        socketRef.current.send(jsonString);
        return true;
      } catch (err) {
        console.error("Error sending WebSocket message:", err);
        throw err;
      }
    } else {
      console.warn("WebSocket not connected, cannot send message. State:", 
        socketRef.current ? ['CONNECTING', 'OPEN', 'CLOSING', 'CLOSED'][socketRef.current.readyState] : 'null');
      throw new Error("WebSocket is not connected");
    }
  }, []);

  return {
    sendMessage,
    lastMessage,
    readyState,
    connectionStatus,
    error
  };
}
