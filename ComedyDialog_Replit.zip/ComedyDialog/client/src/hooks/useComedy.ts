import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Message {
  speaker: "cathy" | "joe";
  message: string;
}

interface ComedySettings {
  topic: string;
  customTopic?: string;
  turns: number;
  style: string;
}

export function useComedy() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [audienceCount, setAudienceCount] = useState(254);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  // This runs on the first render to set up the audience counter
  useEffect(() => {
    const interval = setInterval(() => {
      setAudienceCount(prevCount => {
        const change = Math.floor(Math.random() * 5) - 2; // Random change between -2 and +2
        return Math.max(prevCount + change, 1);
      });
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);

  // Define the mutation to start a comedy conversation
  const comedyMutation = useMutation({
    mutationFn: async (settings: ComedySettings) => {
      const actualTopic = settings.topic === "custom" && settings.customTopic
        ? settings.customTopic
        : settings.topic;
      
      const response = await apiRequest(
        "POST",
        "/api/comedy/conversation",
        { 
          topic: actualTopic,
          turns: settings.turns,
          style: settings.style
        }
      );
      
      return response.json();
    },
    onSuccess: (data) => {
      setMessages(data.messages);
      toast({
        title: "Comedy show started!",
        description: "Enjoy the show!",
      });
    },
    onError: (err: Error) => {
      console.error("Error starting comedy conversation:", err);
      setError("Something went wrong while connecting to the comedy API. " + err.message);
      toast({
        title: "Error",
        description: "Failed to start comedy show. Please try again.",
        variant: "destructive",
      });
    },
  });

  const startComedyConversation = (settings: ComedySettings) => {
    setMessages([]);
    comedyMutation.mutate(settings);
  };

  const resetConversation = () => {
    setMessages([]);
  };

  return {
    messages,
    isLoading: comedyMutation.isPending,
    startComedyConversation,
    resetConversation,
    error,
    setError,
    audienceCount,
  };
}
